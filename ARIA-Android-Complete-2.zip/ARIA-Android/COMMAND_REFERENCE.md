# ARIA — Full Voice Command Reference

Say **"Hey ARIA"** first, then any of these:

---

## 📞 Calls
| Say | Action |
|-----|--------|
| "Call Mom" | Dials Mom from contacts |
| "Call John Smith" | Dials John Smith |
| "Dial 07700900123" | Dials the number |
| "Phone Sarah" | Calls Sarah |

---

## 💬 SMS / Texts
| Say | Action |
|-----|--------|
| "Text Mom I'll be late" | Sends SMS to Mom |
| "Send a message to John saying see you tomorrow" | SMS to John |
| "Message Sarah: on my way" | SMS to Sarah |

---

## 📱 Open Apps
| Say | Action |
|-----|--------|
| "Open WhatsApp" | Launches WhatsApp |
| "Open camera" | Launches camera app |
| "Launch Spotify" | Opens Spotify |
| "Open Instagram" | Opens Instagram |
| "Start Chrome" | Opens Chrome |
| "Open settings" | Opens phone settings |

---

## 🔍 Search
| Say | Action |
|-----|--------|
| "Search for quantum physics" | Google search |
| "Google the weather in Tokyo" | Google search |
| "Look up best pizza recipes" | Google search |
| "Find nearby restaurants" | Google search |

---

## 🌐 Open Websites
| Say | Action |
|-----|--------|
| "Open youtube.com" | Opens YouTube |
| "Go to reddit.com" | Opens Reddit |
| "Open https://github.com" | Opens GitHub |

---

## ⏰ Alarms & Timers
| Say | Action |
|-----|--------|
| "Set alarm for 7am" | Sets 7:00 AM alarm |
| "Wake me up at 6:30" | Sets 6:30 AM alarm |
| "Set timer for 5 minutes" | 5-minute countdown |
| "Remind me in 10 minutes" | 10-minute timer |
| "Set alarm for 8:30pm" | Sets 8:30 PM alarm |

---

## 🎵 Music & Media
| Say | Action |
|-----|--------|
| "Play music" | Resumes playback |
| "Play Coldplay" | Searches Spotify/YouTube |
| "Play Shape of You" | Searches for song |
| "Pause" | Pauses current media |
| "Stop music" | Stops playback |
| "Next song" | Skips to next track |
| "Previous song" | Goes back one track |
| "Volume up" | Raises volume |
| "Volume down" | Lowers volume |
| "Mute" | Mutes audio |
| "Unmute" | Unmutes audio |

---

## 🔦 Flashlight
| Say | Action |
|-----|--------|
| "Turn on flashlight" | Torch on |
| "Turn off flashlight" | Torch off |
| "Flashlight" | Toggles torch |
| "Torch on" | Torch on |

---

## 🗺️ Navigation
| Say | Action |
|-----|--------|
| "Navigate to Heathrow Airport" | Opens Google Maps navigation |
| "Take me to Tesco" | Navigation to Tesco |
| "Directions to London Bridge" | Maps directions |
| "Open maps" | Opens Google Maps |

---

## ☁️ Weather
| Say | Action |
|-----|--------|
| "What's the weather?" | Opens weather search |
| "Will it rain today?" | Opens weather |
| "Temperature outside" | Opens weather |

---

## ⚙️ Phone Settings
| Say | Action |
|-----|--------|
| "Open WiFi" | Opens WiFi panel |
| "Open Bluetooth" | Opens Bluetooth panel |
| "Airplane mode" | Opens airplane mode settings |
| "Open brightness" | Opens display settings |
| "Check battery" | Opens battery usage |

---

## 🤖 AI Questions (anything)
| Say | Action |
|-----|--------|
| "What is the speed of light?" | AI answers |
| "Write me a poem about rain" | AI writes poem |
| "Translate hello to Spanish" | AI translates |
| "How do I boil an egg?" | AI explains |
| "What's the capital of Japan?" | AI answers |
| "Explain quantum entanglement" | AI explains |
| "Help me plan my day" | AI helps plan |
| "Give me a recipe for pasta" | AI gives recipe |
| "Ask ChatGPT what 2+2 is" | AI answers |
| "Tell me a joke" | AI tells joke |

---

## Tips

- Wake word is **"hey aria"** by default — change it in Settings
- You can also type any command in the text box
- If the AI isn't responding, check your API key in Settings
- For totally free AI: use OpenRouter (free tier) or Ollama (local)
- To keep ARIA alive in background: Settings → Battery → ARIA → Unrestricted
