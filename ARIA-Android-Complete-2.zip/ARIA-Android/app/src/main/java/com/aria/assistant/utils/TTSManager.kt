package com.aria.assistant.utils

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID

/**
 * TTSManager — wraps Android TTS with a clean, non-blocking API.
 * Interrupts any current speech before speaking new text.
 */
class TTSManager(context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false

    var onSpeakingStarted: (() -> Unit)? = null
    var onSpeakingFinished: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setSpeechRate(1.05f)
                tts?.setPitch(1.0f)
                isReady = true

                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        onSpeakingStarted?.invoke()
                    }
                    override fun onDone(utteranceId: String?) {
                        onSpeakingFinished?.invoke()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        onSpeakingFinished?.invoke()
                    }
                })
                Log.d("ARIA_TTS", "TTS ready")
            } else {
                Log.e("ARIA_TTS", "TTS init failed with status: $status")
            }
        }
    }

    fun speak(text: String) {
        if (!isReady) return
        stop()
        // Clean up markdown for speech
        val clean = text
            .replace(Regex("\\*\\*(.+?)\\*\\*"), "$1")
            .replace(Regex("\\*(.+?)\\*"), "$1")
            .replace(Regex("`(.+?)`"), "$1")
            .replace(Regex("#{1,6}\\s"), "")
            .replace("\n\n", ". ")
            .replace("\n", ". ")
            .take(600)   // Don't speak novels

        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
    }

    fun isSpeaking(): Boolean = tts?.isSpeaking ?: false

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
