package com.aria.assistant.utils

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent

/**
 * MediaHandler — controls media playback by voice.
 *
 * Commands handled:
 *   "play music" / "play [song/artist]"
 *   "pause" / "stop music"
 *   "next song" / "skip"
 *   "previous song"
 *   "volume up" / "volume down"
 *   "mute" / "unmute"
 *   "play [artist] on Spotify / YouTube Music"
 */
object MediaHandler {

    fun handle(text: String, context: Context): String {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

        return when {
            isPause(text)      -> { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PAUSE); "Paused." }
            isStop(text)       -> { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_STOP);  "Stopped." }
            isNext(text)       -> { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT);  "Next track." }
            isPrevious(text)   -> { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS); "Previous track." }
            isMute(text)       -> { audio.adjustVolume(AudioManager.ADJUST_MUTE, 0); "Muted." }
            isUnmute(text)     -> { audio.adjustVolume(AudioManager.ADJUST_UNMUTE, 0); "Unmuted." }
            isVolumeUp(text)   -> { repeat(3) { audio.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI) }; "Volume up." }
            isVolumeDown(text) -> { repeat(3) { audio.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI) }; "Volume down." }
            isPlay(text)       -> handlePlay(text, context)
            else               -> "I didn't understand that media command."
        }
    }

    private fun handlePlay(text: String, context: Context): String {
        val query = text
            .replace(Regex("play( music| song)?( on (spotify|youtube|youtube music))?"), "")
            .trim()

        return if (query.isBlank()) {
            // Just resume
            sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY)
            "Playing."
        } else {
            // Open Spotify search first, fall back to YouTube Music, then YouTube
            val spotifyPackage = "com.spotify.music"
            val ytMusicPackage = "com.google.android.apps.youtube.music"

            val pm = context.packageManager
            val spotifyInstalled = try { pm.getPackageInfo(spotifyPackage, 0); true } catch (e: Exception) { false }
            val ytMusicInstalled = try { pm.getPackageInfo(ytMusicPackage, 0); true } catch (e: Exception) { false }

            when {
                text.contains("spotify", ignoreCase = true) || spotifyInstalled -> {
                    openSpotifySearch(query, context)
                    "Searching Spotify for \"$query\"."
                }
                text.contains("youtube music", ignoreCase = true) || ytMusicInstalled -> {
                    openYTMusicSearch(query, context)
                    "Searching YouTube Music for \"$query\"."
                }
                else -> {
                    openYouTubeSearch(query, context)
                    "Searching YouTube for \"$query\"."
                }
            }
        }
    }

    private fun openSpotifySearch(query: String, context: Context) {
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            openYouTubeSearch(query, context)
        }
    }

    private fun openYTMusicSearch(query: String, context: Context) {
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://music.youtube.com/search?q=${Uri.encode(query)}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    private fun openYouTubeSearch(query: String, context: Context) {
        val intent = Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    private fun sendMediaKey(context: Context, keyCode: Int) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val down = KeyEvent(KeyEvent.ACTION_DOWN, keyCode)
        val up   = KeyEvent(KeyEvent.ACTION_UP, keyCode)
        audio.dispatchMediaKeyEvent(down)
        audio.dispatchMediaKeyEvent(up)
    }

    // ─── Classifiers ──────────────────────────────────────────────────────────
    private fun isPlay(t: String)       = t.contains(Regex("\\bplay\\b"))
    private fun isPause(t: String)      = t.contains(Regex("\\bpause\\b"))
    private fun isStop(t: String)       = t.contains(Regex("\\bstop (music|playing|song|audio)\\b"))
    private fun isNext(t: String)       = t.contains(Regex("\\bnext (song|track)?\\b|\\bskip\\b"))
    private fun isPrevious(t: String)   = t.contains(Regex("\\b(previous|prev|last|go back) (song|track)?\\b"))
    private fun isMute(t: String)       = t.contains(Regex("\\bmute\\b")) && !t.contains("un")
    private fun isUnmute(t: String)     = t.contains(Regex("\\bunmute\\b"))
    private fun isVolumeUp(t: String)   = t.contains(Regex("volume up|louder|turn (it |the volume )?up"))
    private fun isVolumeDown(t: String) = t.contains(Regex("volume down|quieter|turn (it |the volume )?down|lower (the )?volume"))
}
