package com.aria.assistant.ai

import android.content.Context
import android.util.Log
import com.aria.assistant.utils.PrefsManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * AIManager — routes to whichever AI the user configured.
 *
 * Supports:
 *  - OpenRouter (free tier): gives access to Claude, GPT-4, Mistral, Llama, etc.
 *  - Ollama (local, 100% offline, zero cost): runs on-device via Termux or LAN server
 *  - Direct Anthropic API
 *  - Direct OpenAI API
 *
 * OpenRouter free tier gives you Claude Haiku, Mistral-7B, Llama-3 for FREE
 * with rate limits — good enough for a personal assistant.
 * Get key at: https://openrouter.ai (free signup)
 */
class AIManager(private val context: Context) {

    private val prefs = PrefsManager(context)
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val conversationHistory = mutableListOf<JSONObject>()

    companion object {
        // Free models on OpenRouter — no billing needed
        const val MODEL_CLAUDE_HAIKU    = "anthropic/claude-haiku"
        const val MODEL_MISTRAL_FREE    = "mistralai/mistral-7b-instruct:free"
        const val MODEL_LLAMA_FREE      = "meta-llama/llama-3-8b-instruct:free"
        const val MODEL_GEMMA_FREE      = "google/gemma-7b-it:free"

        const val SYSTEM_PROMPT = """You are ARIA, a fast and capable personal voice assistant on Android.
Keep answers SHORT — 2-3 sentences max unless asked to elaborate.
You help with anything: questions, tasks, advice, math, writing, coding, plans.
If asked about phone actions (calls, apps, SMS), say they've already been handled.
Be direct, smart, friendly. No filler phrases."""
    }

    suspend fun ask(query: String): String = withContext(Dispatchers.IO) {
        val provider = prefs.aiProvider

        try {
            when (provider) {
                "ollama"     -> askOllama(query)
                "openai"     -> askOpenAI(query)
                "anthropic"  -> askAnthropic(query)
                else         -> askOpenRouter(query)   // default: openrouter (free)
            }
        } catch (e: Exception) {
            Log.e("ARIA", "AI error: ${e.message}")
            "I hit a snag connecting to AI. Check your internet or AI settings."
        }
    }

    // ─── OpenRouter (Recommended — Free tier) ─────────────────────────────────

    private fun askOpenRouter(query: String): String {
        val apiKey = prefs.openRouterKey
        val model  = prefs.openRouterModel.ifBlank { MODEL_MISTRAL_FREE }

        addToHistory("user", query)
        val messages = buildMessagesJson()

        val body = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("max_tokens", 500)
        }.toString()

        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("HTTP-Referer", "https://aria-assistant.app")
            .addHeader("X-Title", "ARIA Personal Assistant")
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return "No response from AI."

        val json = JSONObject(responseBody)
        if (json.has("error")) {
            val err = json.getJSONObject("error").optString("message", "Unknown error")
            return if (err.contains("key") || err.contains("auth")) {
                "OpenRouter API key is invalid. Please check Settings."
            } else {
                "AI error: $err"
            }
        }

        val reply = json
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getString("content")
            .trim()

        addToHistory("assistant", reply)
        return reply
    }

    // ─── Ollama (Local/LAN — 100% free, no internet needed) ──────────────────

    private fun askOllama(query: String): String {
        val host  = prefs.ollamaHost.ifBlank { "http://localhost:11434" }
        val model = prefs.ollamaModel.ifBlank { "llama3" }

        addToHistory("user", query)

        val body = JSONObject().apply {
            put("model", model)
            put("messages", buildMessagesJson())
            put("stream", false)
        }.toString()

        val request = Request.Builder()
            .url("$host/api/chat")
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return "No response from Ollama."
        val json = JSONObject(responseBody)

        val reply = json
            .getJSONObject("message")
            .getString("content")
            .trim()

        addToHistory("assistant", reply)
        return reply
    }

    // ─── Direct OpenAI ────────────────────────────────────────────────────────

    private fun askOpenAI(query: String): String {
        val apiKey = prefs.openAIKey
        val model  = prefs.openAIModel.ifBlank { "gpt-4o-mini" }

        addToHistory("user", query)

        val body = JSONObject().apply {
            put("model", model)
            put("messages", buildMessagesJson())
            put("max_tokens", 500)
        }.toString()

        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return "No response from OpenAI."
        val json = JSONObject(responseBody)

        val reply = json
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")
            .getString("content")
            .trim()

        addToHistory("assistant", reply)
        return reply
    }

    // ─── Direct Anthropic ─────────────────────────────────────────────────────

    private fun askAnthropic(query: String): String {
        val apiKey = prefs.anthropicKey

        addToHistory("user", query)

        // Anthropic uses separate system field
        val userMessages = JSONArray()
        conversationHistory.forEach { msg ->
            if (msg.getString("role") != "system") {
                userMessages.put(msg)
            }
        }

        val body = JSONObject().apply {
            put("model", "claude-haiku-20240307")
            put("max_tokens", 500)
            put("system", SYSTEM_PROMPT)
            put("messages", userMessages)
        }.toString()

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("Content-Type", "application/json")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: return "No response from Claude."
        val json = JSONObject(responseBody)

        val reply = json
            .getJSONArray("content")
            .getJSONObject(0)
            .getString("text")
            .trim()

        addToHistory("assistant", reply)
        return reply
    }

    // ─── History management ───────────────────────────────────────────────────

    private fun addToHistory(role: String, content: String) {
        conversationHistory.add(JSONObject().apply {
            put("role", role)
            put("content", content)
        })
        // Keep last 20 messages to avoid context overflow
        while (conversationHistory.size > 20) {
            conversationHistory.removeAt(0)
        }
    }

    private fun buildMessagesJson(): JSONArray {
        val arr = JSONArray()
        // System message first
        arr.put(JSONObject().apply {
            put("role", "system")
            put("content", SYSTEM_PROMPT)
        })
        conversationHistory.forEach { arr.put(it) }
        return arr
    }

    fun clearHistory() {
        conversationHistory.clear()
    }
}
