package com.aria.assistant.utils

import android.content.Context
import android.content.SharedPreferences

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("aria_prefs", Context.MODE_PRIVATE)

    // AI Provider: "openrouter" | "ollama" | "openai" | "anthropic"
    var aiProvider: String
        get() = prefs.getString("ai_provider", "openrouter") ?: "openrouter"
        set(v) = prefs.edit().putString("ai_provider", v).apply()

    // OpenRouter
    var openRouterKey: String
        get() = prefs.getString("openrouter_key", "") ?: ""
        set(v) = prefs.edit().putString("openrouter_key", v).apply()

    var openRouterModel: String
        get() = prefs.getString("openrouter_model", "mistralai/mistral-7b-instruct:free") ?: ""
        set(v) = prefs.edit().putString("openrouter_model", v).apply()

    // Ollama (local)
    var ollamaHost: String
        get() = prefs.getString("ollama_host", "http://10.0.2.2:11434") ?: ""
        set(v) = prefs.edit().putString("ollama_host", v).apply()

    var ollamaModel: String
        get() = prefs.getString("ollama_model", "llama3") ?: ""
        set(v) = prefs.edit().putString("ollama_model", v).apply()

    // OpenAI
    var openAIKey: String
        get() = prefs.getString("openai_key", "") ?: ""
        set(v) = prefs.edit().putString("openai_key", v).apply()

    var openAIModel: String
        get() = prefs.getString("openai_model", "gpt-4o-mini") ?: ""
        set(v) = prefs.edit().putString("openai_model", v).apply()

    // Anthropic
    var anthropicKey: String
        get() = prefs.getString("anthropic_key", "") ?: ""
        set(v) = prefs.edit().putString("anthropic_key", v).apply()

    // Wake word
    var wakeWord: String
        get() = prefs.getString("wake_word", "hey aria") ?: "hey aria"
        set(v) = prefs.edit().putString("wake_word", v).apply()

    var alwaysListening: Boolean
        get() = prefs.getBoolean("always_listening", true)
        set(v) = prefs.edit().putBoolean("always_listening", v).apply()

    var voiceEnabled: Boolean
        get() = prefs.getBoolean("voice_enabled", true)
        set(v) = prefs.edit().putBoolean("voice_enabled", v).apply()

    var ttsSpeed: Float
        get() = prefs.getFloat("tts_speed", 1.05f)
        set(v) = prefs.edit().putFloat("tts_speed", v).apply()
}
